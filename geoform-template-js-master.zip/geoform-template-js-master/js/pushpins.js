define([{
    "id": "blue",
    "name": "Blue",
    "url": "./images/pins/blue.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "brown",
    "name": "Brown",
    "url": "./images/pins/brown.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "green",
    "name": "Green",
    "url": "./images/pins/green.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "grey",
    "name": "Grey",
    "url": "./images/pins/grey.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "orange",
    "name": "Orange",
    "url": "./images/pins/orange.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "purple",
    "name": "Purple",
    "url": "./images/pins/purple.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "red",
    "name": "Red",
    "url": "./images/pins/red.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}, {
    "id": "yellow",
    "name": "Yellow",
    "url": "./images/pins/yellow.png",
    "width": 36,
    "height": 36,
    "offset": {
        "x": 9,
        "y": 18
    }
}]);