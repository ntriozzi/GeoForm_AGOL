﻿define(
   ({
    "pagination": {
      "page": "頁",
      "previousTitle": "上一頁",
      "nextTitle": "下一頁",
      "firstTitle": "第一頁",
      "lastTitle": "最後一頁",
      "helip": "&hellip;"
    }
  })
);