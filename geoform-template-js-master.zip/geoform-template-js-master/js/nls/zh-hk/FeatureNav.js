﻿define(
   ({
    layer: "圖層(L)",
    sort: "排序方式",
    order: "順序(O)",
    desc: "降冪",
    asc: "昇冪",
    loading: "載入&hellip；",
    search: "搜尋",
    searchPlaceholder: "尋找報告",
    noResults: "無結果",
    ascending: "昇冪(C)",
    descending: "降冪(C)"
  })
);