﻿define(
   ({
    "pagination": {
      "page": "Side",
      "previousTitle": "Forrige",
      "nextTitle": "Neste",
      "firstTitle": "Første",
      "lastTitle": "Siste",
      "helip": "&hellip;"
    }
  })
);