﻿define(
   ({
    layer: "Lag",
    sort: "Sorter etter",
    order: "Rekkefølge",
    desc: "Synkende",
    asc: "Stigende",
    loading: "loading&hellip;",
    search: "Søke",
    searchPlaceholder: "Søk etter rapporter",
    noResults: "Ingen resultater",
    ascending: "Stigende",
    descending: "Synkende"
  })
);