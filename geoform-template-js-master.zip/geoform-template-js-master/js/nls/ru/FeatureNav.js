﻿define(
   ({
    layer: "Слой",
    sort: "Сортировать по",
    order: "Порядок",
    desc: "Desc",
    asc: "Asc",
    loading: "loading&hellip;",
    search: "Поиск",
    searchPlaceholder: "Найти отчеты",
    noResults: "Нет результатов",
    ascending: "По возрастанию",
    descending: "По убыванию"
  })
);