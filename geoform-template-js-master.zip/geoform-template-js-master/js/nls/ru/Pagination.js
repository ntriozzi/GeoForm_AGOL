﻿define(
   ({
    "pagination": {
      "page": "Страница",
      "previousTitle": "Предыдущий",
      "nextTitle": "Следующий",
      "firstTitle": "Первый",
      "lastTitle": "Последний",
      "helip": "&hellip;"
    }
  })
);