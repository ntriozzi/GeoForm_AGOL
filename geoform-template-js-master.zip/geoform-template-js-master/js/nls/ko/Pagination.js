﻿define(
   ({
    "pagination": {
      "page": "페이지",
      "previousTitle": "이전",
      "nextTitle": "다음",
      "firstTitle": "처음",
      "lastTitle": "마지막",
      "helip": "&hellip;"
    }
  })
);