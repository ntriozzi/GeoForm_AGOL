﻿define(
   ({
    layer: "레이어",
    sort: "정렬 기준",
    order: "순서",
    desc: "내림차순",
    asc: "오름차순",
    loading: "불러오는 중&hellip;",
    search: "검색",
    searchPlaceholder: "보고서 찾기",
    noResults: "결과 없음",
    ascending: "오름차순",
    descending: "내림차순"
  })
);