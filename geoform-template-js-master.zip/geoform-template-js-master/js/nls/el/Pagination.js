﻿define(
   ({
    "pagination": {
      "page": "Σελίδα",
      "previousTitle": "ΠΡΟΗΓΟΥΜΕΝΟ",
      "nextTitle": "ΕΠΟΜΕΝΟ",
      "firstTitle": "Πρώτο",
      "lastTitle": "Τελευταίο",
      "helip": "&έλλειψη"
    }
  })
);