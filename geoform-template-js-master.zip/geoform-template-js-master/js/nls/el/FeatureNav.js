﻿define(
   ({
    layer: "Θεματικό επίπεδο",
    sort: "Ταξινόμηση κατά",
    order: "Σειρά",
    desc: "Φθίνουσα",
    asc: "Αύξουσα",
    loading: "φόρτωση&έλλειψη",
    search: "Αναζήτηση",
    searchPlaceholder: "Εύρεση αναφορών",
    noResults: "Δεν υπάρχουν αποτελέσματα",
    ascending: "Αύξουσα",
    descending: "Φθίνουσα"
  })
);