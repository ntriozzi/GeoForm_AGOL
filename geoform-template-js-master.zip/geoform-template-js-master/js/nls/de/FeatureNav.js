﻿define(
   ({
    layer: "Layer",
    sort: "Sortieren nach",
    order: "Reihenfolge",
    desc: "Beschreibung",
    asc: "Aufsteigend",
    loading: "&hellip;wird geladen",
    search: "Suche",
    searchPlaceholder: "Berichte suchen",
    noResults: "Keine Ergebnisse",
    ascending: "Aufsteigend",
    descending: "Absteigend"
  })
);