﻿define(
   ({
    "pagination": {
      "page": "Seite",
      "previousTitle": "Vorherige(r)",
      "nextTitle": "Nächste(r)",
      "firstTitle": "Erster",
      "lastTitle": "Letzte(r)",
      "helip": "&hellip;"
    }
  })
);