﻿define(
   ({
    "pagination": {
      "page": "ページ",
      "previousTitle": "前へ",
      "nextTitle": "次へ",
      "firstTitle": "最初",
      "lastTitle": "最後",
      "helip": "&hellip;"
    }
  })
);