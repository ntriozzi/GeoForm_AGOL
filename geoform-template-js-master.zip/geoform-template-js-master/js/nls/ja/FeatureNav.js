﻿define(
   ({
    layer: "レイヤー",
    sort: "並べ替え",
    order: "順序",
    desc: "降順",
    asc: "昇順",
    loading: "読み込んでいます...",
    search: "検索",
    searchPlaceholder: "レポートの検索",
    noResults: "検索結果はありません",
    ascending: "昇順",
    descending: "降順"
  })
);