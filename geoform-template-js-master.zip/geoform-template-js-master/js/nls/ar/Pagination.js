﻿define(
   ({
    "pagination": {
      "page": "صفحة",
      "previousTitle": "السابق",
      "nextTitle": "التالي",
      "firstTitle": "الأول",
      "lastTitle": "أخير",
      "helip": "&hellip;"
    }
  })
);