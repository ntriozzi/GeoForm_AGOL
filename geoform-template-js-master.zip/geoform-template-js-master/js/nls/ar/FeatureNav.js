﻿define(
   ({
    layer: "الطبقة",
    sort: "الفرز حسب",
    order: "ترتيب",
    desc: "تنازلي",
    asc: "تصاعدي",
    loading: "تحميل&hellip;",
    search: "بحث",
    searchPlaceholder: "إيجاد التقارير",
    noResults: "بدون نتائج",
    ascending: "تصاعدي",
    descending: "تنازليًا"
  })
);