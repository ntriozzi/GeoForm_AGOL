﻿define(
   ({
    layer: "Camada",
    sort: "Ordenar por",
    order: "Ordem",
    desc: "Desc",
    asc: "Asc",
    loading: "loading&hellip;",
    search: "Pesquisar",
    searchPlaceholder: "Encontrar relatórios",
    noResults: "Sem resultados",
    ascending: "Ascendente",
    descending: "Decrescente"
  })
);