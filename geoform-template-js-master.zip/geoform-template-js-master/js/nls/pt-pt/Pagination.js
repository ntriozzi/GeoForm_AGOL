﻿define(
   ({
    "pagination": {
      "page": "Página",
      "previousTitle": "Anterior",
      "nextTitle": "Seguinte",
      "firstTitle": "Primeiro",
      "lastTitle": "Último",
      "helip": "&hellip;"
    }
  })
);