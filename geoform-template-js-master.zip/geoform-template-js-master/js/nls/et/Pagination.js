﻿define(
   ({
    "pagination": {
      "page": "Lehekülg",
      "previousTitle": "Eelmine",
      "nextTitle": "Järgmine",
      "firstTitle": "Esimene",
      "lastTitle": "Viimane",
      "helip": "&hellip;"
    }
  })
);