﻿define(
   ({
    layer: "Kiht",
    sort: "Sorteeri:",
    order: "Järjekord",
    desc: "Laskuvas järjestuses",
    asc: "Tõusvas järjestuses",
    loading: "loading&hellip;",
    search: "Otsi",
    searchPlaceholder: "Leia aruanded",
    noResults: "Tulemused puuduvad",
    ascending: "Kahanev",
    descending: "Kahanev"
  })
);