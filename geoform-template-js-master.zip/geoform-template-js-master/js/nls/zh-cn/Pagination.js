﻿define(
   ({
    "pagination": {
      "page": "页",
      "previousTitle": "上一页",
      "nextTitle": "下一页",
      "firstTitle": "首页",
      "lastTitle": "尾页",
      "helip": "&hellip;"
    }
  })
);