﻿define(
   ({
    layer: "图层",
    sort: "排序方式",
    order: "顺序",
    desc: "降序",
    asc: "升序",
    loading: "加载&hellip；",
    search: "搜索",
    searchPlaceholder: "查找报告",
    noResults: "无结果",
    ascending: "升序",
    descending: "降序"
  })
);