﻿define(
   ({
    layer: "Camada",
    sort: "Classificar por",
    order: "Ordem",
    desc: "Desc",
    asc: "Asc",
    loading: "carregando&hellip;",
    search: "Pesquisar",
    searchPlaceholder: "Localizar relatórios",
    noResults: "Sem resultados",
    ascending: "Crescente",
    descending: "Descendente"
  })
);