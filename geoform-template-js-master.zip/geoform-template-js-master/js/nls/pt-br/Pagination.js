﻿define(
   ({
    "pagination": {
      "page": "Página",
      "previousTitle": "Anterior",
      "nextTitle": "Avançcar",
      "firstTitle": "Primeiro",
      "lastTitle": "Último",
      "helip": "&hellip;"
    }
  })
);