﻿define(
   ({
    "pagination": {
      "page": "หน้า",
      "previousTitle": "ก่อนหน้า",
      "nextTitle": "ถัดไป",
      "firstTitle": "หน้าแรก",
      "lastTitle": "หน้าสุดท้าย",
      "helip": "&hellip;"
    }
  })
);