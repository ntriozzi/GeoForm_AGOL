﻿define(
   ({
    layer: "ชั้นข้อมูล",
    sort: "จัดลำดับตาม",
    order: "ลำดับ",
    desc: "เรียงจากมากไปน้อย",
    asc: "เรียงจากน้อยไปมาก",
    loading: "กำลังโหลด&hellip;",
    search: "ค้นหา",
    searchPlaceholder: "ค้นหารายงาน",
    noResults: "ไม่มีผลลัพธ์",
    ascending: "เรียงจากน้อยไปมาก",
    descending: "เรียงจากมากไปน้อย"
  })
);