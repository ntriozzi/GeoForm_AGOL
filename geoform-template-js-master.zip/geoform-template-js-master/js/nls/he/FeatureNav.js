﻿define(
   ({
    layer: "שכבה",
    sort: "מיון על ידי",
    order: "סדר",
    desc: "יורד",
    asc: "עולה",
    loading: "טוען&hellip;",
    search: "חפש",
    searchPlaceholder: "חפש דוחות",
    noResults: "אין תוצאות",
    ascending: "עולה",
    descending: "יורד"
  })
);