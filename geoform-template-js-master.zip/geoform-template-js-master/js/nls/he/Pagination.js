﻿define(
   ({
    "pagination": {
      "page": "עמוד",
      "previousTitle": "הקודם",
      "nextTitle": "הבא",
      "firstTitle": "ראשון",
      "lastTitle": "אחרון",
      "helip": "&hellip;"
    }
  })
);