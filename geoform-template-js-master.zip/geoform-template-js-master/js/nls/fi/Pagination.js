﻿define(
   ({
    "pagination": {
      "page": "Sivu",
      "previousTitle": "Edellinen",
      "nextTitle": "Seuraava",
      "firstTitle": "Ensimmäinen",
      "lastTitle": "Viimeinen",
      "helip": "&hellip;"
    }
  })
);