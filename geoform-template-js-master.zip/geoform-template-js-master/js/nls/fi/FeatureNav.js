﻿define(
   ({
    layer: "Karttataso",
    sort: "Lajitteluperuste",
    order: "Järjestä",
    desc: "Laskeva",
    asc: "Nouseva",
    loading: "lataa&hellip;",
    search: "Etsi",
    searchPlaceholder: "Etsi raportit",
    noResults: "Ei tuloksia",
    ascending: "Nouseva",
    descending: "Laskeva"
  })
);