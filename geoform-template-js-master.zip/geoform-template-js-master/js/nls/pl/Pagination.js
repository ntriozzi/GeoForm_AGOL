﻿define(
   ({
    "pagination": {
      "page": "Strona",
      "previousTitle": "Powrót",
      "nextTitle": "Dalej",
      "firstTitle": "Pierwszy",
      "lastTitle": "Ostatni",
      "helip": "&hellip;"
    }
  })
);