﻿define(
   ({
    layer: "Warstwa",
    sort: "Sortuj według",
    order: "Kolejność",
    desc: "Malej",
    asc: "Rosn",
    loading: "Wczytywanie&hellip;",
    search: "Szukaj",
    searchPlaceholder: "Znajdź raporty",
    noResults: "Brak wyników",
    ascending: "Rosnąco",
    descending: "Malejąco"
  })
);