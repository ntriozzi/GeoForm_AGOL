﻿define(
   ({
    "pagination": {
      "page": "Sayfa",
      "previousTitle": "Önceki",
      "nextTitle": "Sonraki",
      "firstTitle": "Birinci",
      "lastTitle": "Son",
      "helip": "&hellip;"
    }
  })
);