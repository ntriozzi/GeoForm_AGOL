﻿define(
   ({
    layer: "Katman",
    sort: "Şuna göre sırala:",
    order: "Sırala",
    desc: "Azalan",
    asc: "Artan",
    loading: "yükleniyor&hellip;",
    search: "Ara",
    searchPlaceholder: "Raporları bul",
    noResults: "Sonuç yok",
    ascending: "Artan",
    descending: "Azalan"
  })
);