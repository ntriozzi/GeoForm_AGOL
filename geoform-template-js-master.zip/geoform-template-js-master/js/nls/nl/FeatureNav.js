﻿define(
   ({
    layer: "Kaartlaag",
    sort: "Sorteren op",
    order: "Volgorde",
    desc: "Aflopend",
    asc: "Oplopend",
    loading: "laden&hellip;",
    search: "Zoeken",
    searchPlaceholder: "Rapporten zoeken",
    noResults: "Geen resultaten",
    ascending: "Oplopend",
    descending: "Aflopend"
  })
);