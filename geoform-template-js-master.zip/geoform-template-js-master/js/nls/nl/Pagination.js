﻿define(
   ({
    "pagination": {
      "page": "Pagina",
      "previousTitle": "Vorige",
      "nextTitle": "Volgende",
      "firstTitle": "Eerste",
      "lastTitle": "Laatste",
      "helip": "&hellip;"
    }
  })
);