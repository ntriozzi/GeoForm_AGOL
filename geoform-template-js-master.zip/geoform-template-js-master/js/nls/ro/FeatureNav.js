﻿define(
   ({
    layer: "Strat tematic",
    sort: "Sortare după",
    order: "Ordine",
    desc: "Desc.",
    asc: "Asc.",
    loading: "încărcare&hellip;",
    search: "Căutare",
    searchPlaceholder: "Găsire rapoarte",
    noResults: "Niciun rezultat",
    ascending: "Ascendent",
    descending: "Descendent"
  })
);