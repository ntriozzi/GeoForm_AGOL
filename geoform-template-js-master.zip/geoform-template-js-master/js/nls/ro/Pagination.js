﻿define(
   ({
    "pagination": {
      "page": "Pagina",
      "previousTitle": "Anterior",
      "nextTitle": "Înainte",
      "firstTitle": "La început",
      "lastTitle": "La sfârşit",
      "helip": "&hellip;"
    }
  })
);