﻿define(
   ({
    "pagination": {
      "page": "Page",
      "previousTitle": "Précédent",
      "nextTitle": "Suivant",
      "firstTitle": "Premier",
      "lastTitle": "Dernier",
      "helip": "&hellip;"
    }
  })
);