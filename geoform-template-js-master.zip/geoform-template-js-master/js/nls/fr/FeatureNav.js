﻿define(
   ({
    layer: "Couche",
    sort: "Trier par",
    order: "Commande",
    desc: "Décroissant",
    asc: "Croissant",
    loading: "chargement&hellip;",
    search: "Rechercher",
    searchPlaceholder: "Rechercher des rapports",
    noResults: "Aucun résultat",
    ascending: "Croissant",
    descending: "Décroissant"
  })
);