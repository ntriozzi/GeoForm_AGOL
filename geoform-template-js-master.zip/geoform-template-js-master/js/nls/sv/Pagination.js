﻿define(
   ({
    "pagination": {
      "page": "Sida",
      "previousTitle": "Föregående",
      "nextTitle": "Nästa",
      "firstTitle": "Första",
      "lastTitle": "Sista",
      "helip": "&hellip;"
    }
  })
);