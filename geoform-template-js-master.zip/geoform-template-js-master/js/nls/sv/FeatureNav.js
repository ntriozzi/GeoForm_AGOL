﻿define(
   ({
    layer: "Lager",
    sort: "Sortera efter",
    order: "Ordning",
    desc: "Fallande",
    asc: "Stigande",
    loading: "laddar&hellip;",
    search: "Sök",
    searchPlaceholder: "Hitta rapporter",
    noResults: "Inga resultat",
    ascending: "Stigande",
    descending: "Fallande"
  })
);