﻿define(
   ({
    "pagination": {
      "page": "Trang",
      "previousTitle": "Trước",
      "nextTitle": "Tiếp theo",
      "firstTitle": "Đầu tiên",
      "lastTitle": "Cuối cùng",
      "helip": "&hellip;"
    }
  })
);