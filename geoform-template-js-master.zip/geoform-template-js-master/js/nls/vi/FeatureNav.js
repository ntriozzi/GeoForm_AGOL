﻿define(
   ({
    layer: "Lớp",
    sort: "Sắp xếp theo",
    order: "Thứ tự",
    desc: "Desc",
    asc: "Asc",
    loading: "đang tải&hellip;",
    search: "Tìm kiếm",
    searchPlaceholder: "Tìm báo cáo",
    noResults: "Không có kết quả",
    ascending: "Tăng dần",
    descending: "Giảm dần"
  })
);