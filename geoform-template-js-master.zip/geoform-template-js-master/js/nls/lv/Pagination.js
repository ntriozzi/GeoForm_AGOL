﻿define(
   ({
    "pagination": {
      "page": "Lapa",
      "previousTitle": "Iepriekšējais",
      "nextTitle": "Tālāk",
      "firstTitle": "Pirmais",
      "lastTitle": "Pēdējais",
      "helip": "&hellip;"
    }
  })
);