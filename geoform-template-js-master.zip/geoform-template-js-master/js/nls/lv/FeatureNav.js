﻿define(
   ({
    layer: "Slānis",
    sort: "Kārtot pēc",
    order: "Secība",
    desc: "Dilst.",
    asc: "Aug.",
    loading: "loading&hellip;",
    search: "Meklēšana",
    searchPlaceholder: "Atrast ziņojumus",
    noResults: "Nav rezultātu",
    ascending: "Pieaugoši",
    descending: "Dilstošā secībā"
  })
);