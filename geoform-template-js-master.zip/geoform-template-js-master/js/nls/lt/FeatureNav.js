﻿define(
   ({
    layer: "Sluoksnis",
    sort: "Rūšiuoti pagal",
    order: "Tvarka",
    desc: "Mažėj",
    asc: "Didėj",
    loading: "įkeliama&hellip;",
    search: "Ieškoti",
    searchPlaceholder: "Rasti ataskaitas",
    noResults: "Rezultatų nėra",
    ascending: "didėjančia tvarka",
    descending: "Mažėjimo tvarka"
  })
);