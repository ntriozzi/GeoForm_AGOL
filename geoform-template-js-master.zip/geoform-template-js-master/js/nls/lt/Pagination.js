﻿define(
   ({
    "pagination": {
      "page": "Puslapis",
      "previousTitle": "Ankstesnis",
      "nextTitle": "Kitas",
      "firstTitle": "Pirmas",
      "lastTitle": "Paskutinis",
      "helip": "&hellip;"
    }
  })
);