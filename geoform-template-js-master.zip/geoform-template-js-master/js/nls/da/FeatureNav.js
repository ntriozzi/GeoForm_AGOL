﻿define(
   ({
    layer: "Lag",
    sort: "Sortér efter",
    order: "Rækkefølge",
    desc: "Faldende",
    asc: "Stigende",
    loading: "loading&hellip;",
    search: "Search",
    searchPlaceholder: "Find rapporter",
    noResults: "Ingen resultater",
    ascending: "Stigende",
    descending: "Faldende"
  })
);