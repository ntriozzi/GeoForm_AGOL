﻿define(
   ({
    "pagination": {
      "page": "Side",
      "previousTitle": "Forrige",
      "nextTitle": "Næste",
      "firstTitle": "Første",
      "lastTitle": "Sidste",
      "helip": "&hellip;"
    }
  })
);