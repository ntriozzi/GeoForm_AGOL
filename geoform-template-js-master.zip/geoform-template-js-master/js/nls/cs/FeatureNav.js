﻿define(
   ({
    layer: "Vrstva",
    sort: "Seřadit podle",
    order: "Pořadí",
    desc: "Sestupně",
    asc: "Vzestupně",
    loading: "načítání&hellip;",
    search: "Hledat",
    searchPlaceholder: "Vyhledat hlášení",
    noResults: "Žádné výsledky",
    ascending: "Vzestupně",
    descending: "Sestupně"
  })
);