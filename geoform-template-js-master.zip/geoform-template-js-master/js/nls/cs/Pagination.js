﻿define(
   ({
    "pagination": {
      "page": "Stránka",
      "previousTitle": "Předchozí",
      "nextTitle": "Další",
      "firstTitle": "První",
      "lastTitle": "Poslední",
      "helip": "&hellip;"
    }
  })
);