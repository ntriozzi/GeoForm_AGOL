﻿define(
   ({
    "pagination": {
      "page": "Pagina",
      "previousTitle": "Precedente",
      "nextTitle": "Seguente",
      "firstTitle": "Prima",
      "lastTitle": "Ultima",
      "helip": "&hellip;"
    }
  })
);