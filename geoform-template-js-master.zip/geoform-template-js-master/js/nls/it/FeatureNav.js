﻿define(
   ({
    layer: "Layer",
    sort: "Ordina secondo",
    order: "Ordina",
    desc: "Decrescente",
    asc: "Crescente",
    loading: "caricamento&hellip;",
    search: "Ricerca",
    searchPlaceholder: "Trova report",
    noResults: "Nessun risultato",
    ascending: "Ascendente",
    descending: "Decrescente"
  })
);